import './App.css'
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import HomePage from './pages/HomePage'
import EditExercisePage from './pages/EditExercisePage';
import CreateExercisePage from './pages/CreateExercisePage';

function App() {
  const [exerciseToEdit, setExerciseToEdit] = useState();

  return (
    <div className = "App">
      <Router>
        <header className ="App-header">
          <h1>My Fitness Tracker</h1>
        </header>
        <div className = "App">
          <Route path = "/" exact>
            <HomePage setExerciseToEdit={setExerciseToEdit}/>
          </Route>
          <Route path = "/add-exercise">
            <CreateExercisePage />
          </Route>
          <Route path = "/edit-exercise">
            <EditExercisePage exerciseToEdit = {exerciseToEdit}/>
          </Route>
        </div>
        <p id = "homeLink">
        <Link to="/"> Home Page</Link>
        </p>
        <footer>
          <p>&copy; 2022 Charles Cal's Exercise Tracker</p>
        </footer>
      </Router>
    </div>
  )
}

export default App;