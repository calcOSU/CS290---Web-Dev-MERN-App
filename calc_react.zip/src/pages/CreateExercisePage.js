import React, { useState } from 'react';
import { useHistory, Link } from "react-router-dom";

export const CreateExercisePage = () => {

    const [name, setName] = useState('');
    const [weight, setWeight] = useState('');
    const [reps, setReps] = useState('');
    const [unit, setUnit] = useState('kg');
    const [date, setDate] = useState('');

    const history = useHistory();

    const addExercise = async() => {
        // to be called in the bottom in the form below
        const newExercise = {name, weight, reps, unit, date}
        // use fetch to send asynchronous request to REST API
        const response = await fetch('/exercises', {
            method: 'POST',
            body: JSON.stringify(newExercise),
            headers: {
                'Content-Type': 'application/json',
            }
        })
        if (response.status === 201) {
            alert("Added the exercise")
        } else {
            alert(`failed to add the exercise.  Status code = ${response.status}`);
        }
        history.push("/");
    };
    return (
        <>
            <div>
                <h1> Add Exercise</h1>
                <input
                    type = "text"
                    placeholder = "Exercise Name"
                    value={name}
                    onChange={e=> setName(e.target.value)} />
                <input
                    type = "number"
                    placeholder = "Enter weight"
                    value={weight}
                    onChange={e=> setWeight(e.target.value)} />
                <input
                    type = "number"
                    placeholder = "Enter reps"
                    value={reps}
                    onChange={e=> setReps(e.target.value)} />
                <select
                    type = "text"
                    placeholder = "Enter Unit"
                    value={unit}
                    onChange={e=> setUnit(e.target.value)} >
                        <option value = 'kg'>kg</option>
                        <option value = 'lb'>lb</option>
                        <option value = "none" selected>select unit</option>
                    </select>
                <input
                    type = "text"
                    placeholder = "Enter Date"
                    value={date}
                    onChange={e=> setDate(e.target.value)} />
                <button onClick = {addExercise}>Add</button>
            </div>
        </>
    )
}

export default CreateExercisePage