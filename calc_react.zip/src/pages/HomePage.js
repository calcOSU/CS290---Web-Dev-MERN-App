import React, { useState, useEffect } from 'react';
import { useHistory, Link } from "react-router-dom";
import ExerciseTable from '../components/ExerciseTable';


function HomePage({ setExerciseToEdit}) {
    const [exercises, setExercises] = useState([]);
    const history = useHistory();

    // onDelete uses the fetch API to send a HTTP request to the web server to delete the exercise, then uses useState 
    // via setExercises to update the DOM
    const onDelete = async _id => {
        const response = await fetch(`/exercises/${_id}`, {method:'DELETE'});
        if (response.status === 204) {
            const newExercises = exercises.filter(e => e._id !== _id);
            setExercises(newExercises);
        } else {
            console.error(` failed to delete exercise with _id = ${_id}, status code = ${response.status}`)
        }
    }
    
    const onEdit = exercise => {
        setExerciseToEdit(exercise);
        history.push('edit-exercise');
    }

    const loadExercises =async() => {
        const response = await fetch('/exercises');
        const data = await response.json();
        setExercises(data);
    }

    useEffect(() => {
        loadExercises()
    }, []);

    return (
        <>
            <h2> Exercise List </h2>
            <ExerciseTable exercises={exercises} onDelete = {onDelete} onEdit = {onEdit}></ExerciseTable>
            <Link to="/add-exercise">Add an exercise</Link>
        </>
    )
}

export default HomePage;

