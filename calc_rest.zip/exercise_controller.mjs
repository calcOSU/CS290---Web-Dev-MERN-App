import * as exercise from './exercise_model.mjs'
import express from 'express';

const app = express()
app.use(express.static('public'));
app.use(express.urlencoded({extended: true}));
app.use(express.json());

const PORT = 3000;

/*
Route handler to retrieve a single movie based on its ID
*/
app.post("/exercises", (req, res) => {
    exercise.createExercise(req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date )
        .then(exercise => {
            res.set('Content-Type', 'application/json')
            res.status(201).json(exercise)
        })
        .catch(error => {
            console.log(error);
            res.status(500).json({Error: "request failed"});
        })
});

/*
Router handler to find all exercises in the database
*/

app.get('/exercises', (req,res) => {
    exercise.findExercises()
        .then(exercises => {
            res.set('Content-Type', 'application/json')
            res.status(200).json(exercises);
        })
        .catch(error => {
            console.error(error);
            res.status(500).json({Error: "request failed"});
        })
})

/*
Route handler for /update
*/

app.put("/exercises/:_id", (req,res) => {
    exercise.replaceExercise(req.params._id, req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date)
        .then(numUpdated => {
            if (numUpdated === 1) {
                res.set('Content-Type', 'application/json')
                res.status(200).json({id:req.params._id, name: req.body.name, reps : req.body.reps, weight : req.body.weight, units : req.body.units, date: req.body.date})
            } else {
                res.status(500).json({Error: "resource not found"});
            }
        })
        .catch(error => {
            console.error(error);
            res.status(500).json({Error: "request failed"});
        })
        });




/* 
Router Handler for delete
*/
app.delete('/exercises/:_id', (req, res) => {
    exercise.deleteById(req.params._id)
        .then(deletedCount => {
            if (deletedCount === 1 ) {
                res.status(204).send();
            } else {
                res.status(500).json({Error: "resource not found"});
            }
        })
        .catch(error => {
            console.error(error);
            res.status(500).json({Error: "request failed"});
        })
})

app.listen(PORT, () => {
    console.log(`server listening on ${PORT}`)
})



/*
Route handler to retrieve the exercise with the given id

app.get('/exercises/:id', (req,res) => {
    const exerciseId = req.params.id;
    exercise.findExerciseById(exerciseId)
        .then(exercise => {
            res.set('Content-Type', 'application/json')
            if (exercise !== null ) {
                res.status(200).json(exercise);
            } else {
                res.status(500).json({Error: "resource not found"});
            }})
        .catch(error => {
            res.status(500).json({Error: 'request failed'})
        })
            
});
*/